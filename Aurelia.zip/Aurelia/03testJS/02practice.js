// Code goes here
let name = 'sankar';
let age = 25;

var Person = {
  name,
  age
}