var arr01 = () => 100;
console.log(arr01);
console.log(arr01());


let Person = {
    name1: 'san',
    place:'ASV',
    doLearn: () => {
        console.dir(this);
        console.log("### I'm " + this.name1 + " and learning!!!");
        let whichLocation=()=>{
            console.dir(this);
            console.log(this.place +" is the location" );
        }
        return whichLocation;
    },
    whoLearns: function () {
        console.dir(this);
        console.log("### " + this.name1 + " is learning");
        let whichLocation=()=>{
            console.dir(this);
            console.log(this.place +" is the location" );
        }
        return whichLocation;
    }
}

//Person.doLearn();
Person.doLearn()();
//Person.whoLearns();
Person.whoLearns()();

//Person.doLearn.call({name1:'Stranger'});
//Person.whoLearns.call({name1:'Stranger'});


