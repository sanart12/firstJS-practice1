import {ToDo} from '../model/Todo'

export class TodoService {
    constructor() {
        this.todos = [];
    }
    addTodo(title) {
        //let newTodo=new ToDo((this.todos[this.todos.length].id|this.todos[this.todos.length].id+1,1),title);
        let newTodo = new ToDo(title);
        this.todos.push(newTodo);
        //  console.log(this.todos);
    }
    
    editTodo(id, title) {
        this.todos.forEach((item) => {
            if (item.id === id) {
                item.title = title;
            }
        });

        /* this.todos.forEach(check);
        function check(item)
        {
            if(item.id===id)
            {
                item.title=title;
            }
        } */
    }
    completeTodo(id) {
        this.todos.forEach((item) => {
            if (item.id === id) {
                item.completed = true;
            }
        })
    }
    deleteTodo(id) {

        this.todos.splice(this.todos.findIndex((item) => (item.id === id)), 1);

//return true;
        /* this.todos.forEach(check);
        var temp;
        function check(item)
        {
            if(item.id===id)
            {
                temp=item;
            }
        } */
        //console.log(temp);
        //console.log(this.todos.findIndex(temp));

    }
    completeAll() {
        this.todos.forEach((item) => { item.completed = true; });
/* 
        this.todos.forEach(check);
        function check(item)
        {
            {
                item.completed=true;
            }
        }
 */    }
    clearCompleted() {

 //        this.todos.splice(this.todos.findIndex((item) => (item.completed)), 1);

        this.todos.forEach((item,idx)=>{ 
            console.log("to be deleted: "+item.id);
            this.viewAll();
            
            if(item.completed){
              //  delete this.todos[idx]; // to avoid the concurrent delete issues
//                this.todos.splice(idx,1); //alternate elements missed while delete using the index
             this.deleteTodo(item.id); //alternate elements missed while delete using the index
            }
        });
/*
 
        this.todos.forEach(check);
        function check(item) {
            {
                if (item.completed) {
                    this.todos.deleteTodo(item.id);
                }
            }
        } 
*/
        console.log("### Still trying....");

    }
    viewAll(status) {
        this.todos.forEach((item) => { console.log(item); });

        // this.todos.forEach(check);
        // function check(item)
        // {
        //     {
        //         console.log(item);
        //     }
        // }
    }

}

