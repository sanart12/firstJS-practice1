
class ToDo {
    constructor( title) {
        this.id = ToDo.id++;                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                 ;
        this.title = title;
        this.completed = false;
    }
}
ToDo.id=0;

export {ToDo};